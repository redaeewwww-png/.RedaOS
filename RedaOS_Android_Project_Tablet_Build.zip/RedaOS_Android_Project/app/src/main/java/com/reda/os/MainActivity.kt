package com.reda.os

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val Navy = Color(0xFF0B1424)
private val Panel = Color(0xE8202D42)
private val Blue = Color(0xFF2589E8)
private val TextMain = Color(0xFFF3F7FF)
private val TextSoft = Color(0xFFB8C7D9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RedaDesktop() }
    }
}

data class DeskApp(val name: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val detail: String)

@Composable
fun RedaDesktop() {
    val apps = listOf(
        DeskApp("الملفات", Icons.Default.Folder, "مدير الملفات\nهذه نسخة أولية. يمكن ربطها لاحقاً بملفات الجهاز عبر منتقي الملفات الرسمي."),
        DeskApp("الملاحظات", Icons.Default.EditNote, "اكتب أفكارك وملاحظاتك هنا."),
        DeskApp("الحاسبة", Icons.Default.Calculate, "الحاسبة قيد التطوير."),
        DeskApp("الإعدادات", Icons.Default.Settings, "إعدادات واجهة Reda OS\n• المظهر الداكن\n• اللغة العربية\n• تخطيط مناسب للتابلت"),
        DeskApp("حول النظام", Icons.Default.Info, "Reda OS 1.0\nواجهة مكتبية تجريبية تعمل كتطبيق أندرويد.")
    )
    var startOpen by remember { mutableStateOf(false) }
    var activeApp by remember { mutableStateOf<DeskApp?>(null) }
    var clock by remember { mutableStateOf(SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())) }

    LaunchedEffect(Unit) {
        while (true) {
            clock = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            kotlinx.coroutines.delay(30_000)
        }
    }

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF101D34), Color(0xFF153E68), Color(0xFF07111F)))
        )
    ) {
        // Desktop wallpaper artwork
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(maxWidth * 0.72f).background(
                    Brush.radialGradient(listOf(Color(0x553C9DF2), Color.Transparent)),
                    CircleShape
                )
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Reda", fontSize = 54.sp, fontWeight = FontWeight.Bold, color = TextMain)
                Text("OS", fontSize = 25.sp, color = Color(0xFF8CC7FF), letterSpacing = 9.sp)
                Spacer(Modifier.height(8.dp))
                Text("Your tablet. Your workspace.", color = TextSoft, fontSize = 13.sp)
            }
        }

        // Desktop shortcuts
        Column(
            modifier = Modifier.align(Alignment.TopStart).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            apps.take(4).forEach { app ->
                Column(
                    modifier = Modifier.width(76.dp).clickable { activeApp = app },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(app.icon, null, tint = TextMain, modifier = Modifier.size(31.dp))
                    Spacer(Modifier.height(5.dp))
                    Text(app.name, color = TextMain, fontSize = 12.sp)
                }
            }
        }

        // Open app window
        activeApp?.let { app ->
            var offset by remember(app.name) { mutableStateOf(Offset(0f, 0f)) }
            Card(
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset { IntOffset(offset.x.roundToInt(), offset.y.roundToInt()) }
                    .fillMaxWidth(0.78f)
                    .heightIn(min = 250.dp, max = maxHeight * 0.72f)
                    .shadow(22.dp, RoundedCornerShape(18.dp))
                    .pointerInput(app.name) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            offset += drag
                        }
                    },
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column {
                    Row(
                        Modifier.fillMaxWidth().background(Color(0xFF172338)).padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(app.icon, null, tint = Color(0xFF8CC7FF))
                        Spacer(Modifier.width(10.dp))
                        Text(app.name, color = TextMain, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        IconButton(onClick = { activeApp = null }) {
                            Icon(Icons.Default.Close, "إغلاق", tint = TextMain)
                        }
                    }
                    Text(app.detail, color = TextSoft, modifier = Modifier.padding(22.dp), lineHeight = 25.sp)
                }
            }
        }

        // Start menu
        if (startOpen) {
            Card(
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 76.dp)
                    .fillMaxWidth(0.72f).heightIn(max = maxHeight * 0.72f),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xF21B293D))
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text("ابدأ", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))
                    Text("التطبيقات المثبتة", color = TextSoft, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    LazyVerticalGrid(columns = GridCells.Fixed(3), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(apps) { app ->
                            Column(
                                Modifier.fillMaxWidth().clickable {
                                    activeApp = app
                                    startOpen = false
                                }.padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(app.icon, null, tint = Color(0xFF8CC7FF), modifier = Modifier.size(29.dp))
                                Spacer(Modifier.height(6.dp))
                                Text(app.name, color = TextMain, fontSize = 12.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Reda OS 1.0  •  Android", color = TextSoft, fontSize = 11.sp)
                }
            }
        }

        // Taskbar
        Row(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Color(0xE9101928)).padding(horizontal = 14.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { startOpen = !startOpen }) {
                Icon(Icons.Default.Widgets, "ابدأ", tint = Color(0xFF8CC7FF), modifier = Modifier.size(27.dp))
            }
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = { activeApp = apps[0] }) {
                Icon(Icons.Default.Folder, "الملفات", tint = TextMain)
            }
            IconButton(onClick = { activeApp = apps[3] }) {
                Icon(Icons.Default.Settings, "الإعدادات", tint = TextMain)
            }
            Spacer(Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.End) {
                Text(clock, color = TextMain, fontSize = 12.sp)
                Text(SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date()), color = TextSoft, fontSize = 10.sp)
            }
            Spacer(Modifier.width(10.dp))
            Icon(Icons.Default.Wifi, null, tint = TextSoft, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
            Icon(Icons.Default.BatteryFull, null, tint = TextSoft, modifier = Modifier.size(18.dp))
        }
    }
}
